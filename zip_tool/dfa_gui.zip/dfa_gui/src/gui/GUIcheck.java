package gui;

public class GUIcheck {

    public static void main(String[] args) {
        Gui gui = new Gui();
        gui.setVisible(true);
    }
}
