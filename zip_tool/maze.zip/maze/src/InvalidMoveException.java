/** Exception used to signal that there is a wall in the way of a move */
public class InvalidMoveException extends Exception {
}
